import React, { useState, useEffect } from 'react';
import { FileText, Download, Plus, Trash2, Save } from 'lucide-react';
import { jsPDF } from 'jspdf';
import 'jspdf-autotable';

interface Participant {
  id: string;
  name: string;
  type: string;
}

// LocalStorageのキー
const STORAGE_KEY = 'invoice-participants';
const TEAM_NAME_KEY = 'invoice-team-name';
const REPRESENTATIVE_KEY = 'invoice-representative';
const CHAT_HISTORY_KEY = 'invoice-chat-history';

interface ChatMessage {
  timestamp: string;
  teamName: string;
  participants: Participant[];
  total: number;
}

function App() {
  const [participants, setParticipants] = useState<Participant[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEY);
    return saved ? JSON.parse(saved) : [];
  });
  
  const [newNames, setNewNames] = useState('');
  const [teamName, setTeamName] = useState(() => {
    return localStorage.getItem(TEAM_NAME_KEY) || '';
  });
  const [representativeName, setRepresentativeName] = useState(() => {
    return localStorage.getItem(REPRESENTATIVE_KEY) || '';
  });
  const [chatHistory, setChatHistory] = useState<ChatMessage[]>(() => {
    const saved = localStorage.getItem(CHAT_HISTORY_KEY);
    return saved ? JSON.parse(saved) : [];
  });

  // データが変更されたらLocalStorageに保存
  useEffect(() => {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(participants));
  }, [participants]);

  useEffect(() => {
    localStorage.setItem(TEAM_NAME_KEY, teamName);
  }, [teamName]);

  useEffect(() => {
    localStorage.setItem(REPRESENTATIVE_KEY, representativeName);
  }, [representativeName]);

  useEffect(() => {
    localStorage.setItem(CHAT_HISTORY_KEY, JSON.stringify(chatHistory));
  }, [chatHistory]);

  const calculateFee = (type: string) => {
    const baseFee = type.startsWith('BD') ? 0 : 5000;
    let ticketCount = 0;

    if (type === 'BD1') {
      ticketCount = 2;
    } else if (type === 'BD2') {
      ticketCount = 1;
    } else if (type === 'BD3') {
      ticketCount = 0;
    } else {
      ticketCount = 2;
    }

    const ticketFee = ticketCount * 3000;

    return {
      baseFee,
      ticketCount,
      ticketFee,
      total: baseFee + ticketFee
    };
  };

  const addParticipants = () => {
    if (!newNames.trim()) return;

    const namePattern = /^(.+?)(BD[123])?$/;
    const newParticipantsList = newNames
      .split('\n')
      .filter(name => name.trim())
      .map(name => {
        const match = name.trim().match(namePattern);
        if (match) {
          const [, baseName, type = '通常'] = match;
          return {
            id: crypto.randomUUID(),
            name: baseName.trim(),
            type: type || '通常'
          };
        }
        return null;
      })
      .filter((p): p is Participant => p !== null);

    const updatedParticipants = [...participants, ...newParticipantsList];
    setParticipants(updatedParticipants);
    setNewNames('');

    // チャット履歴に追加
    const total = updatedParticipants.reduce((sum, p) => sum + calculateFee(p.type).total, 0);
    const newMessage: ChatMessage = {
      timestamp: new Date().toLocaleString('ja-JP'),
      teamName,
      participants: updatedParticipants,
      total
    };
    setChatHistory([...chatHistory, newMessage]);
  };

  const removeParticipant = (id: string) => {
    const updatedParticipants = participants.filter(p => p.id !== id);
    setParticipants(updatedParticipants);

    // チャット履歴に追加
    const total = updatedParticipants.reduce((sum, p) => sum + calculateFee(p.type).total, 0);
    const newMessage: ChatMessage = {
      timestamp: new Date().toLocaleString('ja-JP'),
      teamName,
      participants: updatedParticipants,
      total
    };
    setChatHistory([...chatHistory, newMessage]);
  };

  const clearAllData = () => {
    if (window.confirm('全てのデータを削除してもよろしいですか？')) {
      setParticipants([]);
      setTeamName('');
      setRepresentativeName('');
      setChatHistory([]);
      localStorage.removeItem(STORAGE_KEY);
      localStorage.removeItem(TEAM_NAME_KEY);
      localStorage.removeItem(REPRESENTATIVE_KEY);
      localStorage.removeItem(CHAT_HISTORY_KEY);
    }
  };

  const exportChatHistory = () => {
    const content = chatHistory.map(msg => {
      return `
日時: ${msg.timestamp}
チーム名: ${msg.teamName}
参加者数: ${msg.participants.length}名
合計金額: ¥${msg.total.toLocaleString()}
参加者:
${msg.participants.map(p => `- ${p.name} (${p.type})`).join('\n')}
----------------------------------------`;
    }).join('\n');

    const blob = new Blob([content], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `請求書履歴_${new Date().toLocaleDateString('ja-JP')}.txt`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  const generatePDF = async () => {
    // フォントの読み込みを待機
    await new Promise<void>((resolve) => {
      const link = document.createElement('link');
      link.href = 'https://fonts.googleapis.com/css2?family=Noto+Sans+JP&display=swap';
      link.rel = 'stylesheet';
      link.onload = () => resolve();
      document.head.appendChild(link);
    });

    // PDFドキュメントの作成
    const doc = new jsPDF({
      orientation: 'p',
      unit: 'mm',
      format: 'a4',
      putOnlyUsedFonts: true,
      compress: true
    });

    // フォントの設定
    doc.setFont('helvetica');
    doc.setLanguage('ja');

    // タイトル
    doc.setFontSize(18);
    doc.text('請求書', 105, 20, { align: 'center' });

    // チーム情報
    doc.setFontSize(12);
    doc.text(`チーム名：${teamName}`, 20, 40);
    doc.text(`代表者名：${representativeName}`, 20, 50);

    const tableData = participants.map(participant => {
      const fees = calculateFee(participant.type);
      return [
        participant.name,
        participant.type,
        `¥${fees.baseFee.toLocaleString()}`,
        `${fees.ticketCount}枚 (¥${fees.ticketFee.toLocaleString()})`,
        `¥${fees.total.toLocaleString()}`
      ];
    });

    const total = participants.reduce((sum, participant) => {
      return sum + calculateFee(participant.type).total;
    }, 0);

    // テーブルの設定
    doc.autoTable({
      head: [['名前', '種別', '参加費', 'チケット', '合計']],
      body: tableData,
      startY: 60,
      styles: {
        font: 'helvetica',
        fontSize: 10,
        cellPadding: 5
      },
      headStyles: {
        fillColor: [66, 66, 66],
        textColor: [255, 255, 255],
        fontSize: 10
      },
      theme: 'grid'
    });

    // 総合計
    doc.setFontSize(12);
    doc.text(`総合計: ¥${total.toLocaleString()}`, 105, doc.lastAutoTable.finalY + 20, { align: 'center' });

    // 振込先情報
    doc.text('■振込先', 20, doc.lastAutoTable.finalY + 40);
    doc.text('三菱UFJ銀行 青山支店', 30, doc.lastAutoTable.finalY + 50);
    doc.text('普通 4742439', 30, doc.lastAutoTable.finalY + 60);
    doc.text('ウエムラ シュンスケ', 30, doc.lastAutoTable.finalY + 70);
    
    // PDFの保存
    doc.save('請求書.pdf');
  };

  return (
    <div className="min-h-screen bg-gray-50 py-8 px-4">
      <div className="max-w-4xl mx-auto">
        <div className="bg-white rounded-lg shadow-md p-6 mb-6">
          <div className="flex justify-between items-center mb-6">
            <h1 className="text-2xl font-bold flex items-center gap-2">
              <FileText className="w-6 h-6" />
              請求書生成システム
            </h1>
            <div className="flex gap-4">
              <button
                onClick={exportChatHistory}
                className="text-blue-500 hover:text-blue-700 text-sm flex items-center gap-1"
                title="履歴をエクスポート"
              >
                <Save className="w-4 h-4" />
                履歴保存
              </button>
              <button
                onClick={clearAllData}
                className="text-red-500 hover:text-red-700 text-sm flex items-center gap-1"
              >
                <Trash2 className="w-4 h-4" />
                全データを削除
              </button>
            </div>
          </div>

          {/* チーム情報入力 */}
          <div className="grid grid-cols-2 gap-4 mb-6">
            <div>
              <label htmlFor="teamName" className="block text-sm font-medium text-gray-700 mb-1">
                チーム名
              </label>
              <input
                type="text"
                id="teamName"
                value={teamName}
                onChange={(e) => setTeamName(e.target.value)}
                className="w-full px-4 py-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                placeholder="チーム名を入力"
              />
            </div>
            <div>
              <label htmlFor="representativeName" className="block text-sm font-medium text-gray-700 mb-1">
                代表者名
              </label>
              <input
                type="text"
                id="representativeName"
                value={representativeName}
                onChange={(e) => setRepresentativeName(e.target.value)}
                className="w-full px-4 py-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                placeholder="代表者名を入力"
              />
            </div>
          </div>

          <div className="flex gap-2 mb-6">
            <div className="flex-1">
              <textarea
                value={newNames}
                onChange={(e) => setNewNames(e.target.value)}
                placeholder="名前を入力（1行に1人）
例：
田中太郎
山田花子BD1
佐藤一郎BD2"
                className="w-full px-4 py-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 h-32 font-mono"
              />
              <p className="text-sm text-gray-500 mt-1">
                ※バックダンサーの場合は名前の後ろにBD1、BD2、BD3を付けてください
              </p>
            </div>
            <button
              onClick={addParticipants}
              className="bg-blue-500 text-white px-4 py-2 rounded-md hover:bg-blue-600 flex items-center gap-2 h-fit"
            >
              <Plus className="w-4 h-4" />
              追加
            </button>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full mb-6">
              <thead>
                <tr className="bg-gray-50">
                  <th className="px-4 py-2 text-left">名前</th>
                  <th className="px-4 py-2 text-left">種別</th>
                  <th className="px-4 py-2 text-right">参加費</th>
                  <th className="px-4 py-2 text-right">チケット</th>
                  <th className="px-4 py-2 text-right">合計</th>
                  <th className="px-4 py-2"></th>
                </tr>
              </thead>
              <tbody>
                {participants.map((participant) => {
                  const fees = calculateFee(participant.type);
                  return (
                    <tr key={participant.id} className="border-b">
                      <td className="px-4 py-2">{participant.name}</td>
                      <td className="px-4 py-2">{participant.type}</td>
                      <td className="px-4 py-2 text-right">¥{fees.baseFee.toLocaleString()}</td>
                      <td className="px-4 py-2 text-right">{fees.ticketCount}枚 (¥{fees.ticketFee.toLocaleString()})</td>
                      <td className="px-4 py-2 text-right">¥{fees.total.toLocaleString()}</td>
                      <td className="px-4 py-2">
                        <button
                          onClick={() => removeParticipant(participant.id)}
                          className="text-red-500 hover:text-red-700"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </td>
                    </tr>
                  );
                })}
                <tr className="font-bold bg-gray-50">
                  <td colSpan={4} className="px-4 py-2 text-right">総合計:</td>
                  <td className="px-4 py-2 text-right">
                    ¥{participants.reduce((sum, p) => sum + calculateFee(p.type).total, 0).toLocaleString()}
                  </td>
                  <td></td>
                </tr>
              </tbody>
            </table>
          </div>

          {/* 振込先情報 */}
          <div className="mb-6 p-4 bg-gray-50 rounded-md">
            <h3 className="font-semibold mb-2">■振込先</h3>
            <p>三菱UFJ銀行 青山支店</p>
            <p>普通 4742439</p>
            <p>ウエムラ シュンスケ</p>
          </div>

          <button
            onClick={generatePDF}
            disabled={participants.length === 0 || !teamName || !representativeName}
            className="bg-green-500 text-white px-4 py-2 rounded-md hover:bg-green-600 disabled:bg-gray-400 disabled:cursor-not-allowed flex items-center gap-2"
          >
            <Download className="w-4 h-4" />
            PDFを生成
          </button>
          {(!teamName || !representativeName) && (
            <p className="text-sm text-red-500 mt-2">
              ※PDFを生成するにはチーム名と代表者名を入力してください
            </p>
          )}
        </div>

        <div className="bg-white rounded-lg shadow-md p-6">
          <h2 className="text-xl font-bold mb-4">料金について</h2>
          <div className="space-y-6">
            <div>
              <h3 className="font-semibold mb-2">通常参加</h3>
              <ul className="list-disc list-inside">
                <li>参加費 5,000円 + チケット2枚 (¥3,000 × 2枚 = 6,000円)</li>
                <li className="font-bold">合計: 11,000円</li>
              </ul>
            </div>

            <div>
              <h3 className="font-semibold mb-2">バックダンサー区分</h3>
              <div className="space-y-4">
                <div>
                  <h4 className="font-medium">BD1（フル出演）</h4>
                  <ul className="list-disc list-inside">
                    <li>曲頭から最後までほぼ出演</li>
                    <li>チケット2枚 (¥3,000 × 2枚 = 6,000円)</li>
                    <li className="font-bold">合計: 6,000円</li>
                  </ul>
                </div>
                <div>
                  <h4 className="font-medium">BD2（ハーフ出演）</h4>
                  <ul className="list-disc list-inside">
                    <li>半分程度の出演時間</li>
                    <li>チケット1枚 (¥3,000 × 1枚 = 3,000円)</li>
                    <li className="font-bold">合計: 3,000円</li>
                  </ul>
                </div>
                <div>
                  <h4 className="font-medium">BD3（ちょい役）</h4>
                  <ul className="list-disc list-inside">
                    <li>短時間の出演</li>
                    <li>チケットなし</li>
                    <li className="font-bold">合計: 0円</li>
                  </ul>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default App;